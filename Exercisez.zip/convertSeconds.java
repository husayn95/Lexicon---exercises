/* a program that converts seconds to hours, minutes and seconds
        Input seconds: 86399
        Expected output:
        23:59:59 */

public class convertSeconds {
    public static void main(String[] args) {
        int amountSeconds = 3600;
        int hour = (amountSeconds / 60) / 60;
        int minute = ((amountSeconds / 60) % 60);
        int second = (amountSeconds % 60);
        System.out.println(hour + ":" + minute + ":" + second);
    }
}
