//a Java program that prints the average of three numbers
public class AverageNumber {
    public static void main(String[] args) {
        int number1 = 5;
        int number2 = 6;
        int number3 = 7;
        int averageNumber = (number1 + number2 + number3) / 3;
        System.out.println(averageNumber);
    }
}
